# scikit-vector-fields

An open source Python library to perform basics vector field computations. The library is designed for electromagnetic field computations and visualization. However many features can be used for other vector fields in general. 

The library supports the following three major field objects.

### Vector

### Space

### Field

In addition a plotting and visualization module is planned to enable easy visualization of the fields. 
