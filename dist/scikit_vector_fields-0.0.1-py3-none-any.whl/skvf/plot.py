"""Plot commands"""



def field_scalar():
	print('Control is here')
	
	
